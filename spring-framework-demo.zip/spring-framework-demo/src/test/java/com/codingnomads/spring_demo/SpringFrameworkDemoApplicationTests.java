package com.codingnomads.spring_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringFrameworkDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
